# cfc-blueteam

Node version for this project: Node v18.16.0,
v18.17.0 has also been used without issues.

When starting the backend make sure there is a folder named 'uploads'
If this folder is not found please create one.
